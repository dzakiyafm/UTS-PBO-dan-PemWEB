const express = require('express');
const db = require('../models/db');
const router = express.Router();

// Route untuk halaman login
router.get('/login', (req, res) => {
    res.render('login', { error: null });
});

// Route untuk memproses login
router.post('/login', (req, res) => {
    const { email, password } = req.body;
    db.query('SELECT * FROM admins WHERE email = ? AND password = ?', [email, password], (err, results) => {
        if (err) throw err;
        if (results.length > 0) {
            req.session.isAuthenticated = true;
            res.redirect('/kamar');
        } else {
            res.render('login', { error: 'Email atau password salah' });
        }
    });
});

module.exports = router;
