const express = require('express');
const db = require('../models/db');
const router = express.Router();

// Middleware untuk memeriksa autentikasi
router.use((req, res, next) => {
    if (!req.session.isAuthenticated) {
        return res.redirect('/auth/login');
    }
    next();
});

// Route untuk halaman Data Kamar
router.get('/', (req, res) => {
    db.query('SELECT * FROM kamar', (err, results) => {
        if (err) throw err;
        res.render('kamar', { kamars: results });
    });
});

// Route untuk menambah kamar
router.post('/', (req, res) => {
    const { jumlah_kamar, tipe_kamar, harga, check_in, check_out } = req.body;
    db.query('INSERT INTO kamar (jumlah_kamar, tipe_kamar, harga, check_in, check_out) VALUES (?, ?, ?, ?, ?)', 
    [jumlah_kamar, tipe_kamar, harga, check_in, check_out], (err) => {
        if (err) throw err;
        res.redirect('/kamar');
    });
});

// Route untuk menghapus kamar
router.post('/delete/:id', (req, res) => {
    db.query('DELETE FROM kamar WHERE id = ?', [req.params.id], (err) => {
        if (err) throw err;
        res.redirect('/kamar');
    });
});

// Route untuk mengedit kamar
router.get('/edit/:id', (req, res) => {
    db.query('SELECT * FROM kamar WHERE id = ?', [req.params.id], (err, results) => {
        if (err) throw err;
        res.render('editKamar', { kamar: results[0] });
    });
});

router.post('/edit/:id', (req, res) => {
    const { jumlah_kamar, tipe_kamar, harga, check_in, check_out } = req.body;
    db.query('UPDATE kamar SET jumlah_kamar = ?, tipe_kamar = ?, harga = ?, check_in = ?, check_out = ? WHERE id = ?', 
    [jumlah_kamar, tipe_kamar, harga, check_in, check_out, req.params.id], (err) => {
        if (err) throw err;
        res.redirect('/kamar');
    });
});

module.exports = router;
